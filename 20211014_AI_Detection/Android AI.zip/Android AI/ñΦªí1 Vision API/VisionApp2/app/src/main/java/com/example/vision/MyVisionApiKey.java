package com.example.vision;

public class MyVisionApiKey {
    public static final String API_KEY1_VISION = "Your API Key";
}
