package com.example.myfragment;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    FragmentManager fm;
    FragmentTransaction ft;
    Fragment1 fragment1;
    Fragment2 fragment2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fm = getSupportFragmentManager();
        fragment1 = (Fragment1) fm.findFragmentById(R.id.fragment1);
        fragment2 = (Fragment2) fm.findFragmentById(R.id.fragment2);
        if (fragment1 == null && fragment2 == null) {
            fragment1 = new Fragment1();
            fragment2 = new Fragment2();
            showFrag1();
        }
    }

    public void showFrag1() {
        ft = fm.beginTransaction();
        // ft.hide(fragment2).show(fragment1).commit();
        ft.setCustomAnimations(R.anim.anim_in, R.anim.anim_out);
        ft.replace(R.id.activity_main, fragment1).commit();
    }

    public void showFrag2() {

        ft = fm.beginTransaction();
        // ft.hide(fragment1).show(fragment2).commit();
        ft.setCustomAnimations(R.anim.anim_in, R.anim.anim_out);
        ft.replace(R.id.activity_main, fragment2).commit();

    }
}
