package com.example.myfragment;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment1 extends ListFragment implements View.OnClickListener {

    String[] data = {
            "Android",
            "Activity",
            "Fragment",
            "ListView",
            "ListAdapter"
    };
    Context mContext;

    public Fragment1() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment1, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        View root = getView();
        Button button = (Button) root.findViewById(R.id.button1);
        if (button != null)
            button.setOnClickListener(this);
        ListView lv = getListView();
        ListAdapter adapter = new ArrayAdapter<>(mContext, android.R.layout.simple_list_item_1, data);
        lv.setAdapter(adapter);
    }

    public void onClick(View v) {
        ((MainActivity) mContext).showFrag2();
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Snackbar.make(v, "項目" + (position + 1), Snackbar.LENGTH_SHORT).show();
    }
}
