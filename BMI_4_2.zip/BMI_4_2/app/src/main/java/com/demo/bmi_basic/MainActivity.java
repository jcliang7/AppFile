package com.demo.bmi_basic;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "BmiApp";
    Button button;
    EditText fieldheight;
    EditText fieldweight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "MainActivity - onCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
        setListeners();
    }

    private void setListeners(){
        Log.d(TAG, "MainActivity - setListeners()");
        button.setOnClickListener(listener);
    }

    private void findViews(){
        Log.d(TAG, "MainActivity - findViews()");
        button = findViewById(R.id.submit);
        fieldheight = findViewById(R.id.height);
        fieldweight = findViewById(R.id.weight);
    }

    View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Log.d(TAG, "MainActivity - OnClickListener() - onClick");
            Intent intent = new Intent(MainActivity.this, Report.class);
            Bundle bundle = new Bundle();
            bundle.putString("KEY_HEIGHT",fieldheight.getText().toString() );
            bundle.putString("KEY_WEIGHT",fieldweight.getText().toString() );
            intent.putExtras(bundle);
            startActivity(intent);

//            try {
//                    double BMI = calcBMI();
//                    showResult(BMI);
//                    openOptionsDialog();
//            }catch(Exception e){
//
//            }
        }
    };

    private void openOptionsDialog() {
        Log.d(TAG, "MainActivity - openOptionsDialog()");
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.dialog_title)
                .setMessage(R.string.dialog_message)
                .setPositiveButton(R.string.dialog_button_confirm, null)
                .setNeutralButton(R.string.homepage_label, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d(TAG, "MainActivity - openOptionsDialog() - onClick");
                        Uri uri = Uri.parse("geo:24.957405,121.240760");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                })
                .setNegativeButton(R.string.dialog_button_cancel, null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Log.d(TAG, "MainActivity - onCreateOptionsMenu()");
        menu.add(0,10,0,"關於").setIcon(android.R.drawable.ic_menu_help).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(0,20,0,"結束").setIcon(android.R.drawable.ic_menu_delete).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Log.d(TAG, "MainActivity - onOptionsItemSelected()");
        int id = item.getItemId();

        if(id==10){
            Toast.makeText(this,item.getTitle(), Toast.LENGTH_SHORT).show();
        }else if(id==20){
            Toast.makeText(this,item.getTitle(), Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }


}