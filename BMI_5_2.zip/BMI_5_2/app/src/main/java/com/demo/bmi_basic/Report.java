package com.demo.bmi_basic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Report extends AppCompatActivity {

    private static final String TAG = "BmiApp";
    TextView result;
    TextView suggest;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "Report - onCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        findViews();
        setListeners();
        showResult( calcBMI());
    }

    private double calcBMI(){
        Log.d(TAG, "Report - calcBMI()");
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        double height = Double.parseDouble(bundle.getString("KEY_HEIGHT")) / 100;
        double weight = Double.parseDouble(bundle.getString("KEY_WEIGHT"));
        double BMI = weight / (height * height);
        return BMI;
    }

    private void showResult(double BMI){
        Log.d(TAG, "Report - showResult()");
        DecimalFormat df = new DecimalFormat("0.00");
        result.setText(df.format(BMI));

        if(BMI>25)
            suggest.setText(R.string.advice_heavy);
        else if(BMI<20)
            suggest.setText(R.string.advice_light);
        else
            suggest.setText(R.string.advice_average);
    }

    private void findViews(){
        Log.d(TAG, "Report - findViews()");
        result = findViewById(R.id.result);
        suggest = findViewById(R.id.suggest);
        back =  findViewById(R.id.report_back);
    }

    private void setListeners(){
        Log.d(TAG, "Report - setListeners()");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Report.this.finish();
            }
        });
    }
}